import spacy
from spacy.lang.en.stop_words import STOP_WORDS
from string import punctuation
from heapq import nlargest
from googletrans import Translator

text=""" Definite article" redirects here. For the comedy album, see Definite Article.A definite article is an article that marks a definite noun phrase. Definite articles, such as the English the, are used to refer to a particular member of a group. It may be something that the speaker has already mentioned, or it may be otherwise something uniquely specified.For example, Sentence 1 uses the definite article and thus, expresses a request for a particular book. In contrast, Sentence 2 uses an indefinite article and thus, conveys that the speaker would be satisfied with any book.Give me the book.Give me a book.The definite article can also be used in English to indicate a specific class among other classes.The cabbage white butterfly lays its eggs on members of the Brassica genus.However, recent developments show that definite articles are morphological elements linked to certain noun types due to lexicalization. Under this point of view, definiteness does not play a role in the selection of a definite article more than the lexical entry attached to the article.Some languages (such as the continental North Germanic languages, Bulgarian or Romanian) have definite articles only as suffixes.Indefinite article.An indefinite article is an article that marks an indefinite noun phrase. Indefinite articles are those such as English "a" or "an", which do not refer to a specific identifiable entity. Indefinites are commonly used to introduce a new discourse referent which can be referred back to in subsequent discussion:A monster ate a cookie. His name is Cookie Monster.
Indefinites can also be used to generalize over entities who have some property in common:
A cookie is a wonderful thing to eat.
  """
def summarizer(text):
    translater =Translator()
    out = translater.translate(text , dest="kn")
    print(out)
    
    stopwords=list(STOP_WORDS)
    print(stopwords)

    nlp = spacy.load('en_core_web_sm')
    doc = nlp(text)
    print(doc)

    tokens =[token.text for token in doc]
    print(tokens)
    

    word_freq={}
    for word in doc:
       if word.text.lower() not in stopwords and word.text.lower() not in punctuation:
           if word.text not in word_freq.keys():
              word_freq[word.text] =1
           else:
              word_freq[word.text] += 1

    print(word_freq)

    max_freq= max(word_freq.values())
    print(max_freq)

    for word in word_freq.keys():
       word_freq[word]= word_freq[word]/max_freq
       print(word_freq)

    sent_tokens =[sent for sent in doc.sents]
    print(sent_tokens)

    sent_scores = {}
    for sent in sent_tokens:
       for word in sent:
          if word.text in word_freq.keys():
              if sent not in sent_scores.keys():
                 sent_scores[sent]=word_freq[word.text]
              else:
                 sent_scores[sent] += word_freq[word.text]

     print(sent_scores)
    select_len =int(len(sent_tokens) * 0.50)
    print(select_len)
    summary = nlargest(select_len,sent_scores,key = sent_scores.get)
    print(summary)
    
    final_summary = [word.text for word in summary]
    summary = ' '.join(final_summary)
    print(text)
    print(summary)
    translater =Translator()
    outs = translater.translate(summary , dest="kn")
    print(outs)
    print("Length of original text",len(text.split(' ')))
    print("Length of summary text",len(summary.split(' ')))

    
